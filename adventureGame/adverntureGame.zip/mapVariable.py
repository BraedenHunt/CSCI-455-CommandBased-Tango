###############################################################################################
# Map Variable
###############################################################################################
adventureMap = [
    {   #room 1
        'east':2
    },
    {   #room 2
        'south':7,
        'east':3,
        'west':1
    },
    {   #room 3
        'south':8,
        'west':2
    },
    {   #room 4
        'east':5
    },
    {   #room 5
        'west':4,
        'south':10
    },
    {   #room 6
        'east':7,
        'south':11
    },
    {   #room 7
        'north':2,
        'west':6,
        'south':12
    },
    {   #room 8
        'north':3
    },
    {   #room 9
        'east':10,
        'south':14
    },
    {   #room 10
        'north':5,
        'west':9,
        'south':15
    },
    {   #room 11
        'north':6,
        'south':16
    },
    {   #room 12
        'north':7,
        'east':13
    },
    {   #room 13
        'east':14,
        'west':12
    },
    {   #room 14
        'west':13,
        'north':9,
        'south':19
    },
    {   #room 15
        'north':10,
        'south':20
    },
    {   #room 16
        'north':11,
        'east':17
    },
    {   #room 17
        'west':16,
        'south':22
    },
    {   #room 18
        'south':23
    },
    {   #room 19
        'north':14,
        'south':24,
        'east':20
    },
    {   #room 20
        'west':19,
        'north':15
    },
    {   #room 21
        'east':22
    },
    {   #room 22
        'west':21,
        'north':17,
        'east':23
    },
    {   #room 23
        'west':22,
        'north':18
    },
    {   #room 24
        'east':25,
        'north':19
    },
    {   #room 25
        'west':24
    }
]
